import web

db = web.database(dbn = 'sqlite', db = 'AuctionBase.db')

######################BEGIN HELPER METHODS######################

# Enforce foreign key constraints
# WARNING: DO NOT REMOVE THIS!
def enforceForeignKey():
    db.query('PRAGMA foreign_keys = ON')

# initiates a transaction on the database
def transaction():
    return db.transaction()
# Sample usage (in auctionbase.py):
#
# t = sqlitedb.transaction()
# try:
#     sqlitedb.query('[FIRST QUERY STATEMENT]')
#     sqlitedb.query('[SECOND QUERY STATEMENT]')
# except Exception as e:
#     t.rollback()
#     print str(e)
# else:
#     t.commit()
#
# check out http://webpy.org/cookbook/transactions for examples

# Returns the current time from your database
def getTime():#updated the query string to match the correct column and table name in your database
    query_string = 'SELECT Time FROM CurrentTime'
    results = query(query_string)
    return results[0].Time
#########
# Wrapper method around web.py's db.query method
def query(query_string, vars = {}):
    return list(db.query(query_string, vars))
# returns a single item specified by the Item's ID in the database
# Note: if the `result' list is empty (i.e. there are no items for a
# a given ID), this will throw an Exception!
def getItemById(itemID):
    query_string = 'SELECT * FROM Items WHERE ItemID = $itemID'
    result = query(query_string, {'itemID': itemID})
    try: return result[0]
    except IndexError: return None
# Returns category based on the specified itemID
def getCategoryById(itemID):
    query_string = 'SELECT group_concat(Category,", ") \
        AS Category FROM Categories WHERE ItemID = $itemID'
    result = query(query_string, {'itemID': itemID})
    try: return result[0]
    except IndexError: return None
# Get bid information from itemID
def getBidById(itemID):
    query_string = 'SELECT UserID AS "ID of Bidder", Time \
        AS "Time of Bid", Amount AS "Price of Bid" FROM Bids \
            WHERE ItemID = $itemID'
    result = query(query_string, {'itemID': itemID})
    try: return result
    except IndexError: return None
# Get winner information from itemID by finding the maximum bid & bidder
def getWinnerById(itemID):
    query_string = 'SELECT * FROM Bids WHERE ItemID = $itemID and \
        Amount = (SELECT Max(Amount) FROM Bids WHERE ItemID = $itemID)'
    result = query(query_string, {'itemID': itemID})
    try: return result[0]
    except IndexError: return None
# Get user information from userID
def getUserById(userID):
    query_string = 'SELECT * FROM Users WHERE UserID = $userID'
    result = query(query_string, {'userID': userID})
    try: return result[0]
    except IndexError: return None
#####################END HELPER METHODS#####################
#additional methods to interact with your database,
# update the current time
def update_current_time(current_time):
    t = transaction()
    try: db.update('CurrentTime', where = 'Time = $currTime', \
        vars = { 'currTime': getTime() }, Time = current_time)
    except Exception as timeException: 
        t.rollback() 
        print(str(timeException))
        raise Exception
    else: t.commit()
#create a new bid on the item from information given if possible
def create_bid(item, user, amount):
    t = transaction()
    try: db.insert('Bids', UserID = user, ItemID = item, \
        Amount = amount, Time = getTime())
    except Exception as bidException: 
        t.rollback()
        return False
    else: 
        t.commit()
        return True
#Get information about related auctions from search fields provided
def search_auction(itemID, userID, category, description, \
    minPrice, maxPrice, status):
    if description is None: description = '%%'#handle corner cases
    else: description = '%' + description + '%'
    if minPrice == '': minPrice = 0;
    else: minPrice = int(minPrice)
    if maxPrice == '': maxPrice = float('inf');
    else: maxPrice = int(maxPrice)
    if status == 'open':#case by case
        query_string = 'SELECT *, group_concat(category,", ") \
            AS Category FROM Items, \
            Categories, CurrentTime WHERE (Categories.ItemID = Items.ItemID) \
                AND (IFNULL($category, "") = "" OR $category = \
                    Categories.category) AND (IFNULL($itemID, "") \
                        = "" OR $itemID = Items.ItemID) AND \
                        (IFNULL($userID, "") = "" OR $userID = \
                            Items.Seller_UserID) AND (Items.Description \
                                LIKE $description) AND \
                                (IFNULL(Items.Currently, Items.First_Bid) >= \
                                    $minPrice) AND (IFNULL(Items.Currently, \
                                        Items.First_Bid) <= $maxPrice) AND \
                                            (Items.Started <= CurrentTime.Time AND \
                                            Items.Ends >= CurrentTime.Time) \
                                                GROUP BY Items.ItemID'
    if status == 'close':
        query_string = 'SELECT *, group_concat(category,", ") \
            AS Category FROM Items, Categories, \
            CurrentTime WHERE (Categories.ItemID = Items.ItemID) \
                AND (IFNULL($category, "") = "" OR $category = \
                    Categories.category) AND (IFNULL($itemID, "") = "" \
                    OR $itemID = Items.ItemID) AND (IFNULL($userID, "") \
                        = "" OR $userID = Items.Seller_UserID) AND \
                            (Items.Description LIKE $description) \
                            AND (IFNULL(Items.Currently, \
                                Items.First_Bid) >= $minPrice) AND \
                                (IFNULL(Items.Currently, Items.First_Bid) \
                                    <= $maxPrice) AND \
                                    (Items.Ends < CurrentTime.Time) \
                                        GROUP BY Items.ItemID'
    if status == 'notStarted': 
        query_string = 'SELECT *, group_concat(category,", ") AS \
            Category FROM Items, Categories, CurrentTime WHERE \
                (Categories.ItemID = Items.ItemID) AND \
                (IFNULL($category, "") = "" OR $category = \
                    Categories.category) AND (IFNULL($itemID, "") = "" \
                        OR $itemID = Items.ItemID) AND (IFNULL($userID, "") \
                            = "" OR $userID = Items.Seller_UserID) \
                            AND (Items.Description LIKE $description) AND \
                                (IFNULL(Items.Currently, Items.First_Bid) \
                                    >= $minPrice) AND (IFNULL(Items.Currently,\
                                        Items.First_Bid) <= $maxPrice) \
                                        AND (Items.Started > CurrentTime.Time)\
                                             GROUP BY Items.ItemID'
    if status == 'all':
        query_string = 'SELECT *, group_concat(category,", ") \
            AS Category FROM Items, Categories, CurrentTime WHERE \
                (Categories.ItemID = Items.ItemID) AND (IFNULL($category, "") \
                    = "" OR $category = Categories.category) AND \
                        (IFNULL($itemID, "") = "" OR $itemID = Items.ItemID) \
                            AND (IFNULL($userID, "") = "" OR $userID = \
                                Items.Seller_UserID) AND (Items.Description \
                                    LIKE $description) AND \
                                        (IFNULL(Items.Currently, \
                                            Items.First_Bid) >= $minPrice) \
                                                AND (IFNULL(Items.Currently, \
                                                    Items.First_Bid) <= \
                                                        $maxPrice) GROUP BY \
                                                            Items.ItemID'
    result = query(query_string, {'category': category, 'itemID': itemID, 'userID': userID, 'description': description, 'minPrice': minPrice, 'maxPrice': maxPrice});
    try: return result
    except IndexError: return None
