SELECT COUNT(*) FROM users WHERE location = "New York";
