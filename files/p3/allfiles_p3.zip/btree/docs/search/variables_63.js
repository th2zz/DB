var searchData=
[
  ['current_5fpage_5fnumber',['current_page_number',['../structbadgerdb_1_1_page_header.html#a3f721c5ce9ef491fdc9d12292f2f4498',1,'badgerdb::PageHeader']]]
];
