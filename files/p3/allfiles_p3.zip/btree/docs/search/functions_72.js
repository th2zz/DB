var searchData=
[
  ['readheader',['readHeader',['../classbadgerdb_1_1_file.html#af55ceccd74f65de593a6fdfb4c77bb8d',1,'badgerdb::File']]],
  ['readpage',['readPage',['../classbadgerdb_1_1_buf_mgr.html#a9f853f0f1d4628e7e14374d0c7c6a4f3',1,'badgerdb::BufMgr::readPage()'],['../classbadgerdb_1_1_file.html#a00ac0e04c45c5c8d5183212eed870e38',1,'badgerdb::File::readPage()'],['../classbadgerdb_1_1_page_file.html#a704f9a4f927c372bb3546a761f88a532',1,'badgerdb::PageFile::readPage()'],['../classbadgerdb_1_1_blob_file.html#aef77c7b9776493212bad13202bd94f58',1,'badgerdb::BlobFile::readPage()']]],
  ['reason',['reason',['../classbadgerdb_1_1_bad_index_info_exception.html#a445797e655d6086c3e4cf5352eb96916',1,'badgerdb::BadIndexInfoException']]],
  ['record_5fid',['record_id',['../classbadgerdb_1_1_invalid_record_exception.html#a7cac504679cb65e114552cf6480e0151',1,'badgerdb::InvalidRecordException']]],
  ['remove',['remove',['../classbadgerdb_1_1_buf_hash_tbl.html#a5739cc2b22c74d62e25c9d3d316144d8',1,'badgerdb::BufHashTbl::remove()'],['../classbadgerdb_1_1_file.html#a1cc69467366badbd68021ac76a91190e',1,'badgerdb::File::remove()']]]
];
