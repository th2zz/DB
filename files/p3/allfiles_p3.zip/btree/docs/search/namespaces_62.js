var searchData=
[
  ['badgerdb',['badgerdb',['../namespacebadgerdb.html',1,'']]]
];
