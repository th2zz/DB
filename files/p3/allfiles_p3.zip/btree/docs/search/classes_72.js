var searchData=
[
  ['recordid',['RecordId',['../structbadgerdb_1_1_record_id.html',1,'badgerdb']]],
  ['ridkeypair',['RIDKeyPair',['../classbadgerdb_1_1_r_i_d_key_pair.html',1,'badgerdb']]]
];
