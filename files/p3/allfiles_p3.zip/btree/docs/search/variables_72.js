var searchData=
[
  ['reason_5f',['reason_',['../classbadgerdb_1_1_bad_index_info_exception.html#af2faa12c3b71e73b573e8f05f304f2ea',1,'badgerdb::BadIndexInfoException']]],
  ['record_5fid_5f',['record_id_',['../classbadgerdb_1_1_invalid_record_exception.html#af1a2e1ad376303aa5411b7d168634586',1,'badgerdb::InvalidRecordException']]],
  ['refbit',['refbit',['../classbadgerdb_1_1_bad_buffer_exception.html#af871746d373d9a16e2203a783e06d00e',1,'badgerdb::BadBufferException']]],
  ['relationname',['relationName',['../structbadgerdb_1_1_index_meta_info.html#acbc581ff8c78929a9dc2dd69eb45c88a',1,'badgerdb::IndexMetaInfo']]],
  ['ridarray',['ridArray',['../structbadgerdb_1_1_leaf_node_int.html#af1502858816ea899eaeaec3371df53a8',1,'badgerdb::LeafNodeInt::ridArray()'],['../structbadgerdb_1_1_leaf_node_double.html#ad68075f70b1e222e853f586ba6717c76',1,'badgerdb::LeafNodeDouble::ridArray()'],['../structbadgerdb_1_1_leaf_node_string.html#ad84243e8bb0dffd14323eb300021d0ff',1,'badgerdb::LeafNodeString::ridArray()']]],
  ['rightsibpageno',['rightSibPageNo',['../structbadgerdb_1_1_leaf_node_int.html#aa4a0bbe2b3f3b750ba26d51daae998e1',1,'badgerdb::LeafNodeInt::rightSibPageNo()'],['../structbadgerdb_1_1_leaf_node_double.html#a44886ec83ec1e074dc42653b8824353f',1,'badgerdb::LeafNodeDouble::rightSibPageNo()'],['../structbadgerdb_1_1_leaf_node_string.html#a492ba54f5943f778326c28085fcb0530',1,'badgerdb::LeafNodeString::rightSibPageNo()']]],
  ['rootpageno',['rootPageNo',['../structbadgerdb_1_1_index_meta_info.html#ac79603b5b67018044bccc56818ec363f',1,'badgerdb::IndexMetaInfo']]]
];
