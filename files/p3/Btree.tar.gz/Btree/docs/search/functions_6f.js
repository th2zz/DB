var searchData=
[
  ['open',['open',['../classbadgerdb_1_1_page_file.html#a6ce21ecc3d5183714f2a9ca2e8cd82c2',1,'badgerdb::PageFile::open()'],['../classbadgerdb_1_1_blob_file.html#a839a74be980532c48e6e0febb88bedc6',1,'badgerdb::BlobFile::open()']]],
  ['openifneeded',['openIfNeeded',['../classbadgerdb_1_1_file.html#a01f5bb019b5c0c468888a8a9d2a48692',1,'badgerdb::File']]],
  ['operator_21_3d',['operator!=',['../structbadgerdb_1_1_record_id.html#a0639e3a101d04340853a2b8eedccdf98',1,'badgerdb::RecordId']]],
  ['operator_2a',['operator*',['../classbadgerdb_1_1_file_iterator.html#a425810cc9834e0a3c97da76cd0a6b10a',1,'badgerdb::FileIterator::operator*()'],['../classbadgerdb_1_1_page_iterator.html#a5e9f06b5a70663086720fd919a5b6bdb',1,'badgerdb::PageIterator::operator*()']]],
  ['operator_2b_2b',['operator++',['../classbadgerdb_1_1_file_iterator.html#a6fa0f1cef8b46bb933ce6f000276ab52',1,'badgerdb::FileIterator::operator++()'],['../classbadgerdb_1_1_page_iterator.html#a2e63f3eea97170b2c566d1549a2215f0',1,'badgerdb::PageIterator::operator++()']]],
  ['operator_3c',['operator<',['../namespacebadgerdb.html#adc180c2688ea4066b6a3d1da5ddeb4cb',1,'badgerdb']]],
  ['operator_3d',['operator=',['../classbadgerdb_1_1_page_file.html#ab6f294a0062d35584311e8b70a1984c7',1,'badgerdb::PageFile::operator=()'],['../classbadgerdb_1_1_blob_file.html#a21f2eacc3cae767bb863b456d172d7aa',1,'badgerdb::BlobFile::operator=()']]],
  ['operator_3d_3d',['operator==',['../structbadgerdb_1_1_file_header.html#ae6439483acdb0eee52654c9c401793ca',1,'badgerdb::FileHeader::operator==()'],['../classbadgerdb_1_1_file_iterator.html#a373f648963527f2dd259980434686645',1,'badgerdb::FileIterator::operator==()'],['../structbadgerdb_1_1_page_header.html#ab5ecd22f86e37705cd7f29bc57255586',1,'badgerdb::PageHeader::operator==()'],['../classbadgerdb_1_1_page_iterator.html#a1111e07de5972ffd9244e312ac938dac',1,'badgerdb::PageIterator::operator==()'],['../structbadgerdb_1_1_record_id.html#a156dc24ebdd2ed2f8ce49b60326646c7',1,'badgerdb::RecordId::operator==()']]]
];
