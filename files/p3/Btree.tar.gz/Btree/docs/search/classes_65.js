var searchData=
[
  ['endoffileexception',['EndOfFileException',['../classbadgerdb_1_1_end_of_file_exception.html',1,'badgerdb']]]
];
