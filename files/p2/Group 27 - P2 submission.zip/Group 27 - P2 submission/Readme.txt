GROUP 27 Team Member:

NAME: Huanran Li	CS_LOGINS: huanran	WISC_ID: 9075285727
NAME: Tinghe Zhang	CS_LOGINS: tinghe	WISC_ID: 9075197393
NAME: Ruolei Zeng	CS_LOGINS: ruolei	WISC_ID: 9078294627





Assumption:

Part A:
1. Query 7 results are accurate up to 5 decimal places.
2. Query 8 results are accurate up to 3-4 decimal places.
3. Query 10 results are accurate up to 4-5 decimal places, but some results are more accurate than corresponding results in the p2results.pdf

Part B:
1. For any yes/no question, type 1 represents yes and 0 represents no.
2. The program set the search_path to "hw2" as the beginning. So if the table typed in is without any schema, it is supposed to refer the table in schema hw2.
3. The program would also ask for the schema that the user have permission to write, so that each sample table created is inside this schema. The writer personally tested tables created in the schema : huanran.



