DROP VIEW IF EXISTS view1 CASCADE;
DROP VIEW IF EXISTS view2 CASCADE;
DROP VIEW IF EXISTS store_dept_sales_summary CASCADE;

/*Which departments contribute to at least 5% of store sales across for at least 3 stores? */

/*total sum of sales for each department in each store*/
CREATE VIEW view1 AS
SELECT  store, dept, sum(weeklysales) as dept_totalsales FROM (SELECT DISTINCT store, dept, weekdate, weeklysales FROM hw2.Sales) AS Q1 GROUP BY store,dept;


/*每个store总销售额*/
CREATE VIEW view2 AS
SELECT store, sum(weeklysales) as store_totalsales FROM (SELECT DISTINCT store, dept, weekdate, weeklysales FROM hw2.Sales) AS Q1
GROUP BY store;


CREATE VIEW store_dept_sales_summary AS 
SELECT T1.store, T1.dept, T1.dept_totalsales, T1.store_totalsales, T1.dept_totalsales/T1.store_totalsales AS contribution FROM(
	SELECT * FROM(view1 NATURAL INNER JOIN view2)
) AS T1;


/*departments that satisfy conditions*/
CREATE VIEW satisfiable_dept AS
SELECT dept FROM (
SELECT dept, contribution FROM  store_dept_sales_summary
WHERE contribution >= 0.05
) AS Q1
GROUP BY dept
HAVING COUNT(contribution) >=3;


/*TODO calculate avg*/
SELECT ss.dept, AVG(contribution) FROM store_dept_sales_summary ss, satisfiable_dept sd
WHERE ss.dept = sd.dept
GROUP BY ss.dept;



DROP VIEW IF EXISTS view1 CASCADE;
DROP VIEW IF EXISTS view2 CASCADE;
DROP VIEW IF EXISTS store_dept_sales_summary CASCADE;

