DROP VIEW IF EXISTS storedeptyearsmonthscount CASCADE;
DROP VIEW IF EXISTS storedeptcount CASCADE;

/*找到在年份2010-2012有销售额的月数为12的商店及其部门*/
CREATE VIEW storedeptyearsmonthscount AS
SELECT store, dept, years, COUNT(months) as months_count FROM (
SELECT DISTINCT store, dept, extract(month from weekdate) AS months, extract(year from weekdate) AS years FROM hw2.Sales
) T1 WHERE years=2010 OR years=2011 OR years=2012
GROUP BY store, dept, years HAVING COUNT(months) = 12
ORDER BY store, dept, years, months_count;

/*数一下对于每个商店：有几个部门？*/
CREATE VIEW storedeptcount AS
SELECT store, COUNT(dept) as dept_count FROM
(SELECT DISTINCT store, dept FROM hw2.Sales) T1
GROUP BY store;

/*对于表2中的每个商店，数表1中有几行和它相等 => 这个数目如果等于该商店的dept_count则满足条件 had sales in every department in that store for every month of at least
one calendar year among 2010, 2011, and 2012*/
SELECT store FROM storedeptcount s2 WHERE 
(SELECT COUNT(*) FROM storedeptyearsmonthscount s1 WHERE s1.store=s2.store) = dept_count;

DROP VIEW IF EXISTS storedeptcount CASCADE;
DROP VIEW IF EXISTS storedeptyearsmonthscount CASCADE;